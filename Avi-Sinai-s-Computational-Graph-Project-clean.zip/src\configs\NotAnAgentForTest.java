package configs;

public class NotAnAgentForTest {
    public NotAnAgentForTest(String[] subs, String[] pubs) {
    }
}
